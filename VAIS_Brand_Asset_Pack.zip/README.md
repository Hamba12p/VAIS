# VAIS Brand Asset Pack (Edition 01)

Companion to "VAIS Brand Story: The Seam" (PDF).

## Folders
- svg/        Vector artwork: emblem editions, lockups, wordmarks, app icons, avatars (text is converted to outlines, no fonts needed)
- png/        Transparent PNG exports, app icon sizes, favicons, LinkedIn and X banners
- reference/  The master logo and the five generated hero renders (Assets 1 to 5)

## Emblem editions (svg/vais-v-*.svg)
flat, reversed (dark grounds), mono-black, mono-white, mono-teal, dimensional (gradient vector), small and small-reversed (use under 32 px: wider seam, no facet)

## Palette
Intelligence Teal #0E9F8E | Obsidian #141414 | Void #07090A | Mist #F4F7F7 | Registry Paper #EDEAE0
Deep Teal #0A5C57 | Glow Teal #19E6D0 (dark mode only) | Slate #5A6366 | Signal Amber #D99A2B (status only) | Laterite #9C4A24 (heritage accent, sparingly)

## Type
Syncopate Bold (display, capitals only) | IBM Plex Sans (text) | IBM Plex Mono (references, tags). All open source (SIL OFL).

## Notes
- The vector V is built to the proportions of the final logo (about 1.33 : 1). The generated renders (Assets 1 to 5) read slightly taller, so use the vectors wherever exact geometry matters.
- The vector wordmark "AIS" is set in Syncopate Bold as a close match to the lettering in the master logo. The master logo PNG remains the reference for the original glossy lettering.
- Banners include the brand line "Intelligence that holds up in the field." The -clean versions have no text.
- Favicon: png/favicon.ico (16, 32, 48, 64).
